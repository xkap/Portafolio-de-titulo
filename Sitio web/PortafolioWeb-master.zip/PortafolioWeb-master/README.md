Proyecto final de Carrera. Sitio Web con arquitectura inspirada en microservicios usando principalmente Node JS y APIs REST en Node y Django
