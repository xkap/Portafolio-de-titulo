
class Product {
    constructor(productId, name, quantity) {
        this.productId=productId;
        this.name=name;
        this.quantity=quantity;
    }
}

module.exports = Product;