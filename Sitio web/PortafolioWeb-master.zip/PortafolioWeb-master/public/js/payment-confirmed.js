// New order javascript
document.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => {
        window.location.replace('./../'); // redirecting to index
    }, 10 * 4500);
});



