// Config file

let config = {};

config.orchestrator = '';


module.exports = config;