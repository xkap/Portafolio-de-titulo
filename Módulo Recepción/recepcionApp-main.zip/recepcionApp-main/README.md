# recepcionApp
 Módulo de totem de recepción
