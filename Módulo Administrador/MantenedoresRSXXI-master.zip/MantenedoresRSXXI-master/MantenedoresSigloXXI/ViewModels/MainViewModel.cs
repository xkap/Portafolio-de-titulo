﻿using System;

using MantenedoresSigloXXI.Helpers;

namespace MantenedoresSigloXXI.ViewModels
{
    public class MainViewModel : Observable
    {
        public MainViewModel()
        {
        }
    }
}
