﻿namespace MantenedoresSigloXXI.Models
{
    public enum AppTheme
    {
        Light,
        Dark
    }
}
