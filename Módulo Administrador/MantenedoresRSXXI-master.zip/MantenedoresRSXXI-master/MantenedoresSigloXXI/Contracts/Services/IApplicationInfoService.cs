﻿using System;

namespace MantenedoresSigloXXI.Contracts.Services
{
    public interface IApplicationInfoService
    {
        Version GetVersion();
    }
}
