﻿namespace MantenedoresSigloXXI.Contracts.Services
{
    public interface ISystemService
    {
        void OpenInWebBrowser(string url);
    }
}
